const t="qanAt",e="KsQns",r="ucaHs",n="_8WGW7",c="_78TnB",s="kIgdr",a="_25-nr",o={wrapper:t,title:e,flex:r,paper:n,number:c,cardTitle:s,cardText:a};export{o as s};
