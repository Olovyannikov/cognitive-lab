const e="NCEMR",t="c6sr3",n="Es6kP",c="ccUV7",s="UF0t7",o="r535f",r="zGZR5",a="L4d1D",i="x4KYx",l={container:e,title:t,paper:n,name:c,label:s,image:o,reviewText:r,drawer:a,slide:i};export{l as s};
