const t="aKhR1",o="fO1Vd",r="EH0sS",n="t-fgb",e="o-X-I",p="zqIWn",c="ciUC7",s="uY6Cz",x={root:t,grid:o,prev:r,next:n,text:e,paper:p,nextGroup:c,controlWrapper:s};export{x as s};
