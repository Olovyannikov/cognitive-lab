const t="S5fPF",o="SihDo",r="Wrp5Q",s="SXuXk",c="F6iOT",n="rOSqy",e="-d8D6",p={paper:t,root:o,group:r,image:s,title:c,text:n,controls:e};export{p as s};
