const t="_694JK",e="-HwUM",o="kfkYq",s="SImdQ",c="NDUrk",a="-fOm5",n="w64lo",p="xZ7UR",r={paper:t,stack:e,personalityType:o,name:s,image:c,desktop:a,mobile:n,character:p};export{r as s};
