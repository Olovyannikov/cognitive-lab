const o="_--APr",n="rr932",r="YG38Q",e="CpYnV",t="xBYBI",c="jLKvB",g="RYw-O",l={header:o,pinned:n,logoLink:r,burger:e,container:t,logoLarge:c,logoSmall:g};export{l as s};
