import{j as o,L as r}from"./chunk-BGEQTlYR.js";import{C as e}from"./chunk-Vw-CiHAQ.js";const a=()=>o.jsx(e,{mih:200,children:o.jsx(r,{size:"xl",color:"violet.5"})});export{a as P};
