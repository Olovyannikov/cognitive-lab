const n="_5vOBl",o="f0edn",t="FPEK9",c="ww-3b",e="t-ndd",i="OGbCb",s="dGZoU",a="_2raAR",l={section:n,mainTitle:o,accordionLabel:t,item:c,label:e,union:i,content:s,chevron:a};export{l as s};
