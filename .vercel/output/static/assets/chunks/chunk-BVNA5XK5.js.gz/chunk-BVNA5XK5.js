const t="_0-1PX",n="QjnKa",o="H9zrB",c="F029H",e="qMthH",r="vWGvW",s="zdbra",i={root:t,title:n,container:o,content:c,cardTitle:e,cardDescription:r,images:s};export{i as s};
