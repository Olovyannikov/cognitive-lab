import{j as o,bg as r}from"./chunk-B_ojf0d1.js";import{C as e}from"./chunk-BTXdZaaM.js";const a=()=>o.jsx(e,{mih:200,children:o.jsx(r,{size:"xl",color:"violet.5"})});export{a as P};
