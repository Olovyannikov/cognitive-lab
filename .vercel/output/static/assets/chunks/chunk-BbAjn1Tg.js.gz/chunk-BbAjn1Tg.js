import{j as o,L as r}from"./chunk-BMe6mxIZ.js";import{C as e}from"./chunk-CrIpjLcR.js";const a=()=>o.jsx(e,{mih:200,children:o.jsx(r,{size:"xl",color:"violet.5"})});export{a as P};
