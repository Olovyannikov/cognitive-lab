const t="umA3y",o="CzxOQ",s="iETuD",c="c--TE",n="smU66",e="KJpgu",r="t2inC",i={footer:t,topWrapper:o,contacts:s,menu:c,docs:n,divider:e,items:r};export{i as s};
